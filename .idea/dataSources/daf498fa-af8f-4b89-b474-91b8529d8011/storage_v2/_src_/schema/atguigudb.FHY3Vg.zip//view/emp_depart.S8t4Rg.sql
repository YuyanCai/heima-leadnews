create definer = root@localhost view emp_depart as
select concat(`e`.`last_name`, '(', `d`.`department_name`, ')') AS `emp_dept`
from (`atguigudb`.`employees` `e` join `atguigudb`.`departments` `d`)
where (`e`.`department_id` = `d`.`department_id`);

