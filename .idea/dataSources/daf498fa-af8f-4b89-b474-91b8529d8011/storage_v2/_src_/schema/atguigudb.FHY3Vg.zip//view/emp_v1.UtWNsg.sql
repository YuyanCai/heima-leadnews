create definer = root@localhost view emp_v1 as
select `atguigudb`.`employees`.`phone_number` AS `phone_number`,
       `atguigudb`.`employees`.`last_name`    AS `last_name`,
       `atguigudb`.`employees`.`salary`       AS `salary`,
       `atguigudb`.`employees`.`email`        AS `email`
from `atguigudb`.`employees`
where (`atguigudb`.`employees`.`phone_number` like '011%');

