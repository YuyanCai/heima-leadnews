create definer = root@localhost view deptview80 as
select `atguigudb`.`employees`.`employee_id` AS `employee_id`,
       `atguigudb`.`employees`.`last_name`   AS `last_name`,
       `atguigudb`.`employees`.`salary`      AS `salary`
from `atguigudb`.`employees`
where (`atguigudb`.`employees`.`department_id` = 80);

